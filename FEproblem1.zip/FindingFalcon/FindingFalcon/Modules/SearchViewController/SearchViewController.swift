//
//  SearchViewController.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 27/09/23.
//

import UIKit

class SearchViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    
    @IBAction func searchBtnTapped(_ sender: Any) {
        DataManager.shared.homeVCData.selectedPlanetData = Array(repeating: "", count: 4)
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "HomeVCID") as! HomeViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    

}
