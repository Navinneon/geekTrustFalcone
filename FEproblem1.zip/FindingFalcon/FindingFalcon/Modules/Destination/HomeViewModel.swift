//
//  HomeViewModel.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 20/09/23.
//

import Foundation

class HomeViewModel {
    
    var planets = [Planets]()
    let dataManager = DataManager.shared

    func getPlanetsDetails(path: String, completion: @escaping (Result<[Planets], Error>) -> Void) {
        NetworkManager.shared.fetchData(path: path) { result in
            switch result {
            case .success(let data):
                print(String(data: data, encoding: .ascii) ?? "error")
                do {
                    let decoder = JSONDecoder()
                    let planets = try decoder.decode([Planets].self, from: data)
                    completion(.success(planets))
                } catch {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }

}
