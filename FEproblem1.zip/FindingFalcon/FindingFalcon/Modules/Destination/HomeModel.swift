//
//  HomeModel.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 20/09/23.
//
import Foundation

struct Planets: Codable {
    let name: String
    let distance: Int
}
