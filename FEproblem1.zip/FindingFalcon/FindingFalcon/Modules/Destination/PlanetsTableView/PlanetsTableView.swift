//
//  PlanetsTableView.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 20/09/23.
//


import UIKit

protocol UpdateChooseVehicle: AnyObject {
    func update()
}

extension DestinationCollectionViewCell: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return planets.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "planetCell", for: indexPath) as? PlanetTableViewCell else { return UITableViewCell() }

        let data = planets[indexPath.row]
        cell.configure(data: data)
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.planetsTableView.isHidden = true
                
        if tableView.tag == tableViewTag && selectedCell == indexPath.row{
            dataManager.homeVCData.selectedPlanetData[planetsTableView.tag] = ""
        }
        
        if  dataManager.homeVCData.selectedPlanetData.contains(planets[indexPath.row].name) {
            
            self.chooseDestinationLbl.text = "\(planets[indexPath.row].name) is Already Selected Please Choose Another"
            dataManager.homeVCData.selectedPlanetData[planetsTableView.tag] = ""
            chooseDestinationLbl.textColor = .red
        } else {
            dataManager.homeVCData.selectedPlanetData[planetsTableView.tag] = planets[indexPath.row].name
            self.chooseDestinationLbl.text = "Your Selected Destination is \(planets[indexPath.row].name)"
            chooseDestinationLbl.textColor = .theme
        }
        
        tableViewTag = tableView.tag
        selectedCell = indexPath.row
        self.delegate?.update()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 30
    }
    
    
}
