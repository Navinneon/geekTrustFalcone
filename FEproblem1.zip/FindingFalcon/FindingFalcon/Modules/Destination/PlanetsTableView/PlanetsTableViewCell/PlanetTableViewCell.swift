//
//  PlanetTableViewCell.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 20/09/23.
//

import UIKit

class PlanetTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var planetsLbl: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(data: Planets) {
        planetsLbl.text = data.name
    }
    
}
