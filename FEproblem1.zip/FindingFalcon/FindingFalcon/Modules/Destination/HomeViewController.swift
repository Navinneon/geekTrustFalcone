//
//  HomeViewController.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 20/09/23.
//

import UIKit
import SwiftUI

class HomeViewController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var errorLbl: UILabel!
    @IBOutlet weak var collectionBackView: UIView!
    @IBOutlet weak var backview: UIView!
    @IBOutlet weak var chooseVehicleBtn: UIButton!
    
    lazy var viewModel: HomeViewModel = {
        HomeViewModel()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCollectionView()
        setupUI()
        getPlanetsData()
    }
    
    func setupUI() {
        collectionBackView.layer.cornerRadius = 12
        chooseVehicleBtn.layer.cornerRadius = 12
    }
    
    func setupCollectionView() {
        collectionView.delegate = self
        collectionView.dataSource = self
        let nib = UINib(nibName: "DestinationCollectionViewCell", bundle: nil)
        collectionView.register(nib, forCellWithReuseIdentifier: "destinationCell")
    }
    
    func getPlanetsData() {
        self.showSpinner(onView: self.view, theme: .darkGray)
        viewModel.getPlanetsDetails(path: "planets") { [self] result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    viewModel.planets = data
                    viewModel.dataManager.homeVCData.planetData = data
                    self.errorLbl.isHidden = true
                    collectionView.reloadData()
                }
                self.removeSpinner()
            case .failure(let error):
                DispatchQueue.main.async {
                    self.errorLbl.text = error.localizedDescription
                    self.errorLbl.isHidden = false
                }
                self.removeSpinner()
            }
        }
    }
    
    @IBAction func chooseVehicleBtnTap(_ sender: Any) {
        if chooseVehicleBtn.backgroundColor == .theme {
            viewModel.dataManager.chooseVehicleVCData.selectedVehicleIndex = -1
            
            let vc = self.storyboard?.instantiateViewController(identifier: "ChooseVehicleVCID") as! ChooseVehicleViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}

extension HomeViewController: UpdateChooseVehicle{
    func update() {
        if !viewModel.dataManager.homeVCData.selectedPlanetData.contains(""){
            viewModel.dataManager.chooseVehicleVCData.planetNames = viewModel.dataManager.homeVCData.selectedPlanetData
            chooseVehicleBtn.backgroundColor = .theme
        } else {
            chooseVehicleBtn.backgroundColor = .systemGray4
        }
    }
}


