//
//  DestinationCollectionViewCell.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 20/09/23.
//

import UIKit

class DestinationCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var destinationLbl: UILabel!
    @IBOutlet weak var planetsTableView: UITableView!
    @IBOutlet weak var chooseDestinationLbl: UILabel!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var selectBtn: UIButton!
    
    var selectBtnTapped = Bool()
    var planets = [Planets]()
    let dataManager = DataManager.shared
    var tableViewTag = Int()
    var selectedCell = Int()
    
    weak var delegate: UpdateChooseVehicle?

    
    override func awakeFromNib() {
        super.awakeFromNib()
        tableViewCell()
        selectBtn.layer.cornerRadius = 6
    }
    
    func tableViewCell() {
        planetsTableView.delegate = self
        planetsTableView.dataSource = self
        let tableViewCell = UINib(nibName: "PlanetTableViewCell", bundle: nil)
        planetsTableView.register(tableViewCell, forCellReuseIdentifier: "planetCell")
    }
    
    func configure(index: Int) {
        destinationLbl.text = "Destination \(index + 1)"
        chooseDestinationLbl.text = "Click Select to Choose the Destination \(index + 1)"
        planetsTableView.tag = index
    }
    
    func configure(tableData: [Planets]) {
        self.planets = tableData
    }
    
    func update(destination: String) {
        
    }
    
    @IBAction func selectBtnTap(_ sender: Any) {
        selectBtnTapped.toggle()
        
        switch selectBtnTapped {
        case true :
            planetsTableView.isHidden = false
        case false:
            planetsTableView.isHidden = true
        }
    }
    
}
