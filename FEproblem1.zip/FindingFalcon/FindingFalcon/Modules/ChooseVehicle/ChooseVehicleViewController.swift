//
//  ChooseVehicleViewController.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 21/09/23.
//

import UIKit

class ChooseVehicleViewController: UIViewController {
    
    lazy var viewModel: ChooseVehicleViewModel = {
        ChooseVehicleViewModel()
    }()

    @IBOutlet weak var chooseVehicleCollectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var errorLbl: UILabel!
    @IBOutlet weak var instructionBtn: UIButton!
    @IBOutlet weak var backBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupCollectionView()
        getVehiclesData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        viewModel.dataManager.chooseVehicleVCData.selectedIndex = [-1, -1, -1, -1]
    }
    
    func setupCollectionView() {
        chooseVehicleCollectionView.delegate = self
        chooseVehicleCollectionView.dataSource = self
        let nib = UINib(nibName: "ChooseVehicleCollectionViewCell", bundle: nil)
        chooseVehicleCollectionView.register(nib, forCellWithReuseIdentifier: "chooseVehicleCell")
    }
    
    func getVehiclesData() {
        self.showSpinner(onView: self.view, theme: .darkGray)
        viewModel.getVehiclesDetails(path: "vehicles") { [self] result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    viewModel.vehicles = data
                    viewModel.dataManager.chooseVehicleVCData.vehicleData = data
                    chooseVehicleCollectionView.reloadData()
                    self.errorLbl.isHidden = true
                }
                self.removeSpinner()
            case .failure(let error):
                DispatchQueue.main.async {
                    self.errorLbl.text = error.localizedDescription
                    self.errorLbl.isHidden = false
                }
                self.removeSpinner()
            }
        }
    }
    
    
    @IBAction func pageControlTapped(_ sender: UIPageControl) {
        
    }
    
    
    @IBAction func instructionBtnTap(_ sender: Any) {
        
        if viewModel.currentPage < 3 {
            viewModel.currentPage += 1
            if viewModel.dataManager.chooseVehicleVCData.selectedIndex[viewModel.currentPage] < 0 {
                instructionBtn.setTitle("Choose the Vehicle ", for: .normal)
                instructionBtn.setImage( UIImage(systemName: "hand.tap.fill"), for: .normal)
                instructionBtn.isUserInteractionEnabled = false
            } else {
                instructionBtn.setTitle("Next", for: .normal)
                instructionBtn.setImage( UIImage(systemName: "forward.frame"), for: .normal)
                instructionBtn.isUserInteractionEnabled = true
            }
            
            pageControl.currentPage = viewModel.currentPage
            let indexPath = IndexPath(item: viewModel.currentPage, section: 0)
            chooseVehicleCollectionView.scrollToItem(at: indexPath, at: .left, animated: true)
            currentPageTableViewDataReload()
        } else {
            findTheQueen()
        }
         
    }
    
    func currentPageTableViewDataReload() {
        DispatchQueue.main.asyncAfter(deadline: .now()+0.15, execute: { [self] in
            viewModel.vehicles[viewModel.dataManager.chooseVehicleVCData.selectedVehicleIndex].total_no -= 1
            viewModel.dataManager.chooseVehicleVCData.vehicleNames[viewModel.currentPage - 1] = viewModel.vehicles[viewModel.dataManager.chooseVehicleVCData.selectedVehicleIndex].name
           
            viewModel.dataManager.chooseVehicleVCData.selectedVehicleIndex = -1
            chooseVehicleCollectionView.reloadData()
        })
    }

    func findTheQueen() {
        DispatchQueue.main.async{ [self] in
            viewModel.dataManager.chooseVehicleVCData.vehicleNames[viewModel.currentPage] = viewModel.vehicles[viewModel.dataManager.chooseVehicleVCData.selectedVehicleIndex].name
            
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ResultVCID") as! ResultViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    
    func jsonEncoder(data: [Vehicles]) {
        
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            
            let jsonData = try encoder.encode(data)

            if let jsonString = String(data: jsonData, encoding: .utf8) {
                print(jsonString)
            }
        } catch {
            print("Error Encoding JSON: \(error)")
        }
    }
    
    
}

extension ChooseVehicleViewController: UpdateChooseVehicle {

    func update() {
        instructionBtn.isUserInteractionEnabled = true
        if viewModel.currentPage < 3 {
            instructionBtn.setTitle("Next", for: .normal)
            instructionBtn.setImage( UIImage(systemName: "forward.frame"), for: .normal)
        } else {
            instructionBtn.setTitle("Find the Queen", for: .normal)
            instructionBtn.setImage( UIImage(systemName: "location.fill.viewfinder"), for: .normal)
            instructionBtn.isUserInteractionEnabled = true
        }
      
    }
   

}
