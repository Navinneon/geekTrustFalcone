//
//  ChooseVehicleCollectionViewCell.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 21/09/23.
//

import UIKit

class ChooseVehicleCollectionViewCell: UICollectionViewCell {

    
    @IBOutlet weak var destinationLbl: UILabel!
    @IBOutlet weak var vehicleTableView: UITableView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var timetakenLbl: UILabel!
    
    var vehicles = [Vehicles]()
    var selectedIndex = [-1, -1, -1, -1]
    var dataManager = DataManager.shared
    
    weak var delegate: UpdateChooseVehicle?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        tableViewCell()
        mainView.layer.cornerRadius = 12
    }
    
    func tableViewCell() {
        vehicleTableView.delegate = self
        vehicleTableView.dataSource = self
        let tableViewCell = UINib(nibName: "VehicleTableViewCell", bundle: nil)
        vehicleTableView.register(tableViewCell, forCellReuseIdentifier: "vehicleTableCell")
    }
    
    func configure(text: String) {
        destinationLbl.text = text
        timetakenLbl.text = "0 minutes"
    }
    
    func configure(tableData: [Vehicles]) {
        self.vehicles = tableData
       
    }

}

extension ChooseVehicleCollectionViewCell: UpdateTimeOfSelectedVehicle {
    
    func update(distance: Int, speed: Int) {
        let time = distance / speed
        timetakenLbl.text = "\(time) minutes"
    }
}
