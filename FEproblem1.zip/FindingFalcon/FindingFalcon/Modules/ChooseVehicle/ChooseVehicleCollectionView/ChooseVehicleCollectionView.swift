//
//  ChooseVehicleCollectionView.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 21/09/23.
//

import UIKit


extension ChooseVehicleViewController: UICollectionViewDelegate,  UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "chooseVehicleCell", for: indexPath) as? ChooseVehicleCollectionViewCell else { return UICollectionViewCell() }
        
        cell.configure(text: viewModel.dataManager.homeVCData.selectedPlanetData[indexPath.row])
        cell.configure(tableData: viewModel.vehicles)
        cell.vehicleTableView.tag = indexPath.row
        cell.delegate = self
        cell.vehicleTableView.reloadData()
        collectionView.isScrollEnabled = false
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let width = scrollView.frame.width
        pageControl.currentPage = Int(scrollView.contentOffset.x / width)

    }
    
    
}
