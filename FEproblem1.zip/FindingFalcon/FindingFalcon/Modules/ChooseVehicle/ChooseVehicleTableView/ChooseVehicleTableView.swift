//
//  ChooseVehicleTableView.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 23/09/23.
//

import UIKit

protocol UpdateTimeOfSelectedVehicle: AnyObject {
    func update(distance: Int, speed: Int)
}

extension ChooseVehicleCollectionViewCell: UITableViewDelegate, UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vehicles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "vehicleTableCell", for: indexPath) as? VehicleTableViewCell else { return UITableViewCell() }

        let data = vehicles[indexPath.row]
        cell.configure(data: data)
        
        //ChangeSelectedImage
        cell.selectedBtn.tag = indexPath.row
        if cell.selectedBtn.tag == selectedIndex[vehicleTableView.tag] {
            cell.selectedBtn.setImage(UIImage(systemName: "circle.inset.filled"), for: .normal)
        } else {
            cell.selectedBtn.setImage(UIImage(systemName: "circle"), for: .normal)
        }
                
//       Disable the cell if the planet distance is greater than the maximum distance of the vehicle and if the vehicle is zero
        var disable = false
        dataManager.homeVCData.planetData.forEach { planet in
            if (dataManager.homeVCData.selectedPlanetData[vehicleTableView.tag] == planet.name && vehicles[indexPath.row].max_distance < planet.distance) || vehicles[indexPath.row].total_no <= 0 {
                cell.isUserInteractionEnabled = false
                cell.mainView.backgroundColor = .systemGray3.withAlphaComponent(0.5)
                disable = true
            }
        }
        
        if !disable {
            cell.isUserInteractionEnabled = true
            cell.mainView.backgroundColor = .white.withAlphaComponent(1)
        }
        
        cell.selectedBtn.addTarget(self, action: #selector(selectedBttonTapped), for: .touchUpInside)
        
        //Update the time
        if dataManager.chooseVehicleVCData.selectedVehicleIndex != -1 {
            cell.delegate = self
            
            var distance = Int()
            dataManager.homeVCData.planetData.forEach { planet in
                if planet.name == dataManager.homeVCData.selectedPlanetData[vehicleTableView.tag] {
                    distance = planet.distance
                }
            }
            
            let speed = vehicles[dataManager.chooseVehicleVCData.selectedVehicleIndex].speed
            cell.delegate?.update(distance: distance, speed: speed)
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedIndex[vehicleTableView.tag] = indexPath.row
        dataManager.chooseVehicleVCData.selectedIndex[vehicleTableView.tag] = indexPath.row
        dataManager.chooseVehicleVCData.selectedVehicleIndex = indexPath.row
        delegate?.update()
        tableView.reloadData()
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    @objc func selectedBttonTapped(_ sender: UIButton) {

        sender.setImage(UIImage(systemName: "circle.inset.filled"), for: .normal)
        selectedIndex[vehicleTableView.tag] = sender.tag
        dataManager.chooseVehicleVCData.selectedIndex[vehicleTableView.tag] = sender.tag
        for cell in self.vehicleTableView.visibleCells {
            if let othercell = cell as? VehicleTableViewCell {
                if sender.tag != othercell.selectedBtn.tag {
                    othercell.selectedBtn.setImage(UIImage(systemName: "circle"), for: .normal)
                }
            }
        }
        
        //nxtbtn
        dataManager.chooseVehicleVCData.selectedVehicleIndex = sender.tag
        delegate?.update()
        vehicleTableView.reloadData()
    }

    
}
