//
//  VehicleTableViewCell.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 23/09/23.
//


import UIKit

class VehicleTableViewCell: UITableViewCell {
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var selectedBtn: UIButton!
    @IBOutlet weak var vehicleLbl: UILabel!
    @IBOutlet weak var vehicleCount: UILabel!
    
    weak var delegate: UpdateTimeOfSelectedVehicle?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        mainView.layer.cornerRadius = 14
        selectedBtn.setImage(UIImage(systemName: "circle"), for: .normal)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(data: Vehicles){
        vehicleLbl.text = data.name
        vehicleCount.text = "\(data.total_no)"
    }
    
    
    @IBAction func selectedBtnTapped(_ sender: Any) {
      
    }
    
}
