//
//  ChooseVehicleModel.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 21/09/23.
//

import Foundation

struct Vehicles: Codable {
    let name: String
    var total_no: Int
    let max_distance: Int
    let speed: Int
}


