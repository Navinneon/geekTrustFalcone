//
//  ChooseVehicleViewModel.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 21/09/23.
//

import Foundation

class ChooseVehicleViewModel {
    
    var vehicles = [Vehicles]()
    let dataManager = DataManager.shared
    var currentPage = 0

    func getVehiclesDetails(path: String, completion: @escaping (Result<[Vehicles], Error>) -> Void) {
        NetworkManager.shared.fetchData(path: path) { result in
            switch result {
            case .success(let data):
                print(String(data: data, encoding: .ascii) ?? "error")
                do {
                    let decoder = JSONDecoder()
                    let vehicles = try decoder.decode([Vehicles].self, from: data)
                    completion(.success(vehicles))
                } catch {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
}
