//
//  ResultModel.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 25/09/23.
//

import Foundation

struct SendData: Codable {
    var token: String
    var planet_names, vehicle_names: [String]
}

struct Token: Codable {
    var token: String
}

struct SuccessResponse: Codable {
    let planet_name: String?
    let status: String?
    let error: String?
}
