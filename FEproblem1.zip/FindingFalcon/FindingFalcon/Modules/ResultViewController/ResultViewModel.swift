//
//  ResultViewModel.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 25/09/23.
//

import Foundation

class ResultViewModel {
    
    let networkManager = NetworkManager.shared
    let dataManager = DataManager.shared
    var authToken = String()
    
    func getAuthToken(path: String, completion: @escaping (Result<Token, Error>) -> Void) {
        networkManager.getAuthToken(path: path) { result in
            switch result {
            case .success(let data):
                print(String(data: data, encoding: .ascii) ?? "error")
                do {
                    let decoder = JSONDecoder()
                    let token = try decoder.decode(Token.self, from: data)
                    completion(.success(token))
                } catch {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
    func sendTheData(path: String, body: SendData, completion: @escaping (Result<SuccessResponse, Error>) -> Void) {
        
        let jsonEncoder = JSONEncoder()
        if let jsonData = try? jsonEncoder.encode(body) {
            networkManager.sendData(path: path, data: jsonData) { result in
                switch result {
                case .success(let data):
                    print(String(data: data, encoding: .ascii) ?? "error")
                    do {
                        let decoder = JSONDecoder()
                        let response = try decoder.decode(SuccessResponse.self, from: data)
                        if let error = response.error{
                            let customError = NSError(domain: "APIError", code: -1, userInfo: [NSLocalizedDescriptionKey: error])
                            completion(.failure(customError as Error))
                        } else if response.status == "false" {
                            let customError = NSError(domain: "APIError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Status Error"])
                            completion(.failure(customError))
                        } else {
                            completion(.success(response))
                        }
                    } catch {
                        completion(.failure(error))
                    }
                case .failure(let error):
                    completion(.failure(error))
                }
            }
        }
        
    }
}
