//
//  ResultViewController.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 25/09/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var errorLbl: UILabel!
    @IBOutlet weak var planetLbl: UILabel!
    @IBOutlet weak var resetBtn: UIButton!
    @IBOutlet weak var successLbl: UILabel!
    @IBOutlet weak var timeTakenLbl: UILabel!
    @IBOutlet weak var errorView: UIView!
    
    lazy var viewModel: ResultViewModel = {
        ResultViewModel()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        resetBtn.layer.cornerRadius = 4
        getAuthToken()
    }
    
    func getAuthToken() {
        self.showSpinner(onView: self.view, theme: .darkGray)
        viewModel.getAuthToken(path: "token") { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    viewModel.authToken = data.token
                    sendTheData(token: viewModel.authToken)
                    self.successLbl.isHidden = false
                    self.errorLbl.isHidden = true
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    self.errorLbl.text = error.localizedDescription
                    self.errorLbl.isHidden = false
                    self.successLbl.isHidden = true
                    self.removeSpinner()
                }
                
            }
        }
    }
    
    func sendTheData(token: String) {
        
        let sendData = SendData(token: token, planet_names:  viewModel.dataManager.chooseVehicleVCData.planetNames, vehicle_names:  viewModel.dataManager.chooseVehicleVCData.vehicleNames)
        
        viewModel.sendTheData(path: "find", body: sendData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    planetLbl.text = data.planet_name
                    retrieveTheTimeTaken(data: data)
                    errorView.isHidden = true
                    self.errorLbl.isHidden = true
                    self.successLbl.isHidden = false
                    self.removeSpinner()
                }
            case .failure(let error):
                DispatchQueue.main.async { [self] in
                    self.errorLbl.text = error.localizedDescription
                    errorView.isHidden = false
                    self.errorLbl.isHidden = false
                    self.successLbl.isHidden = true
                    self.removeSpinner()
                }
                
            }
        }
    }
    
    func retrieveTheTimeTaken(data: SuccessResponse) {
        var distance = Int()
        var speed = Int()
        
        //distance
        viewModel.dataManager.homeVCData.planetData.forEach { planet in
            if planet.name == data.planet_name {
                distance = planet.distance
            }
        }
        
        //speed
        var index = 0
        viewModel.dataManager.homeVCData.selectedPlanetData.forEach { planet in
            if planet == data.planet_name {
                viewModel.dataManager.chooseVehicleVCData.vehicleData.forEach { vehicle in
                    if vehicle.name == viewModel.dataManager.chooseVehicleVCData.vehicleNames[index] {
                        speed = vehicle.speed
                    }
                }
            }
            index += 1
        }
        
        let time = distance / speed
        timeTakenLbl.text = "\(time) minutes"
    }
    

    @IBAction func resetBtnTap(_ sender: Any) {
        viewModel.dataManager.homeVCData.selectedPlanetData = Array(repeating: "", count: 4)
        self.navigationController?.popToRootViewController(animated: true)
    }
    
}
