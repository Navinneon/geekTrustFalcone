//
//  DataManager.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 20/09/23.
//

import Foundation

class DataManager {
    static let shared = DataManager()
    private init() {}
    
    struct HomeVCData{
        var selectedPlanetData = Array(repeating: "", count: 4)
        var planetData = [Planets]()
    }
    
    struct ChooseVehicleVCData{
        var selectedIndex = [-1, -1, -1, -1]
        var selectedVehicleIndex = -1
        var planetNames = [String]()
        var vehicleNames = ["", "", "", ""]
        var vehicleData = [Vehicles]()
    }
    
    var homeVCData = HomeVCData()
    var chooseVehicleVCData = ChooseVehicleVCData()
    
}
