//
//  Colors.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 20/09/23.
//


import UIKit

extension UIColor {
   
    /// Helper method to verify and return color if assets has it
    
    /// - Parameter colorName: the name of color from asset
    
    /// - Returns: the color from name
    
    private static func named(_ colorName: String) -> UIColor {
        
        guard let color = UIColor(named: colorName) else {
            
            fatalError("The color associted with name \(colorName) could not be found. Please check that you spelled it correctly.")
            
        }
        
        return color
        
    }
    
   
        func image(_ size: CGSize = CGSize(width: 1, height: 1)) -> UIImage {
            return UIGraphicsImageRenderer(size: size).image { rendererContext in
                self.setFill()
                rendererContext.fill(CGRect(origin: .zero, size: size))
            }
        }
           
     
 
    ///  C100 M88 Y4 K0
    
    static var theme: UIColor {  UIColor.named("theme")  }
 
    
    
}







