//
//  ActivityIndicator.swift
//  FindingFalcon
//
//  Created by Navin Kumar R on 20/09/23.
//

import UIKit

var spinnerView : UIView?

extension UIViewController {
    private struct AssociatedKeys {
        static var spinnerView: UIView?
    }
    
    private var spinnerView: UIView? {
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.spinnerView) as? UIView
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.spinnerView, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
        
    }
    
    func showSpinner(onView: UIView, theme: UIColor) {
        let spinnerView = UIView(frame: onView.bounds)
        spinnerView.backgroundColor = UIColor.clear
        let ai = UIActivityIndicatorView(style: .large)
        ai.startAnimating()
        ai.color = theme
        ai.center = spinnerView.center
        
        DispatchQueue.main.async {
            spinnerView.addSubview(ai)
            onView.addSubview(spinnerView)
        }
        
        self.spinnerView = spinnerView
    }
    
    func removeSpinner() {
        DispatchQueue.main.async {
            self.spinnerView?.removeFromSuperview()
            self.spinnerView = nil
        }
    }
}
